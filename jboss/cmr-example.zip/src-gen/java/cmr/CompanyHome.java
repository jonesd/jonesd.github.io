/*
 * Generated file - Do not edit!
 */
package cmr;

import java.lang.*;
import java.util.Collection;
import javax.ejb.CreateException;
import javax.ejb.EntityBean;

/**
 * Home interface for Company. Lookup using {1}
 * @author XDOCLET 1.1.2
 * @xdoclet-generated at Jun 5, 2002 2:49:45 PM
 */
public interface CompanyHome
   extends javax.ejb.EJBHome
{
   public static final String COMP_NAME="java:comp/env/ejb/Company";
   public static final String JNDI_NAME="cmr/Company";

   public cmr.Company create(long id,java.lang.String name) throws java.rmi.RemoteException,javax.ejb.CreateException;

   public cmr.Company findByPrimaryKey(cmr.CompanyKey pk)
      throws java.rmi.RemoteException,javax.ejb.FinderException;

}
