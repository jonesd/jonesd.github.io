/*
 * Generated file - Do not edit!
 */
package cmr;

import java.lang.*;
import java.util.Collection;
import javax.ejb.CreateException;
import javax.ejb.EntityBean;

/**
 * Local interface for Company.
 * @author XDOCLET 1.1.2
 * @xdoclet-generated at Jun 5, 2002 2:49:45 PM
 */
public interface CompanyLocal
   extends javax.ejb.EJBLocalObject
{

   public java.util.Collection getEmployees(  ) ;

   public long getId(  ) ;

   public java.lang.String getName(  ) ;

   public void setEmployees( java.util.Collection value ) ;

}
