/*
 * Generated file - Do not edit!
 */
package cmr;

import java.lang.*;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EntityBean;
import javax.ejb.FinderException;
import javax.naming.NamingException;

/**
 * Remote interface for Employee.
 * @author XDOCLET 1.1.2
 * @xdoclet-generated at Jun 5, 2002 2:49:45 PM
 */
public interface Employee
   extends javax.ejb.EJBObject
{

   public CompanyLocal getCompany(  ) throws java.rmi.RemoteException;

   public CompanyKey getCompanyKey(  ) throws javax.ejb.FinderException, javax.naming.NamingException, java.rmi.RemoteException;

   public java.lang.String getEmail(  ) throws java.rmi.RemoteException;

   public long getId(  ) throws java.rmi.RemoteException;

   public void setCompany( CompanyLocal value ) throws java.rmi.RemoteException;

   public void setCompanyById( long companyId ) throws javax.naming.NamingException, javax.ejb.FinderException, java.rmi.RemoteException;

}
