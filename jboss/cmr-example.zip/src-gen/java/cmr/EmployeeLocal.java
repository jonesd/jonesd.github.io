/*
 * Generated file - Do not edit!
 */
package cmr;

import java.lang.*;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EntityBean;
import javax.ejb.FinderException;
import javax.naming.NamingException;

/**
 * Local interface for Employee.
 * @author XDOCLET 1.1.2
 * @xdoclet-generated at Jun 5, 2002 2:49:45 PM
 */
public interface EmployeeLocal
   extends javax.ejb.EJBLocalObject
{

   public CompanyLocal getCompany(  ) ;

   public CompanyKey getCompanyKey(  ) throws javax.ejb.FinderException, javax.naming.NamingException;

   public java.lang.String getEmail(  ) ;

   public long getId(  ) ;

   public void setCompany( CompanyLocal value ) ;

   public void setCompanyById( long companyId ) throws javax.naming.NamingException, javax.ejb.FinderException;

}
