/*
 * Generated file - Do not edit!
 */
package cmr;

import java.lang.*;
import java.util.Collection;
import javax.ejb.CreateException;
import javax.ejb.EntityBean;

/**
 * Remote interface for Company.
 * @author XDOCLET 1.1.2
 * @xdoclet-generated at Jun 5, 2002 2:49:45 PM
 */
public interface Company
   extends javax.ejb.EJBObject
{

   public java.util.Collection getEmployees(  ) throws java.rmi.RemoteException;

   public long getId(  ) throws java.rmi.RemoteException;

   public java.lang.String getName(  ) throws java.rmi.RemoteException;

   public void setEmployees( java.util.Collection value ) throws java.rmi.RemoteException;

}
