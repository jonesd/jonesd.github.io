/*
 * Generated file - Do not edit!
 */
package cmr;

import java.lang.*;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EntityBean;
import javax.ejb.FinderException;
import javax.naming.NamingException;

/**
 * CMP layer for Employee.
 * @author XDOCLET 1.1.2
 * @xdoclet-generated at Jun 5, 2002 2:49:46 PM
 */
public abstract class EmployeeCMP
   extends cmr.EmployeeBean
   implements javax.ejb.EntityBean
{

   static final long serialVersionUID = -7560819256005374573L;

   public void ejbLoad() 
   {

   }

   public void ejbStore() 
   {
   }

   public void ejbActivate() 
   {
   }

   public void ejbPassivate() 
   {

   }

   public void setEntityContext(javax.ejb.EntityContext ctx) 
   {
   }

   public void unsetEntityContext() 
   {
   }

   public void ejbRemove() 
   {
   }

   public abstract long getId() ;

   public abstract void setId( long id ) ;

   public abstract java.lang.String getEmail() ;

   public abstract void setEmail( java.lang.String email ) ;

}
