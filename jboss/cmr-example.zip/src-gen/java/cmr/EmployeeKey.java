/*
 * Generated file - Do not edit!
 */
package cmr;

import java.lang.*;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EntityBean;
import javax.ejb.FinderException;
import javax.naming.NamingException;

/**
 * Primary key for Employee.
 * @author XDOCLET 1.1.2
 * @xdoclet-generated at Jun 5, 2002 2:49:45 PM
 */
public class EmployeeKey
   extends java.lang.Object
   implements java.io.Serializable
{
   static final long serialVersionUID = -7560819256005374573L;
   transient private int _hashCode = Integer.MIN_VALUE;
   transient private String value = null;

   public long id;

   public EmployeeKey()
   {
   }

   public EmployeeKey( long id )
   {
      this.id = id;
   }

   public long getId()
   {
      return id;
   }

   public void setId(long id)
   {
      this.id = id;
   }

   public int hashCode()
   {
      if( _hashCode == Integer.MIN_VALUE )
      {
         _hashCode += (int)this.id;
      }

      return _hashCode;
   }

   public boolean equals(Object obj)
   {
      if( !(obj instanceof cmr.EmployeeKey) )
         return false;

      cmr.EmployeeKey pk = (cmr.EmployeeKey)obj;
      boolean eq = true;

      if( obj == null )
      {
         eq = false;
      }
      else
      {
         eq = eq && this.id == pk.id;
      }

      return eq;
   }

   public String toString()
   {
      if( value == null )
      {
         value = "[.";
         value += this.id+".";
         value += "]";
      }

      return value;
   }
}
