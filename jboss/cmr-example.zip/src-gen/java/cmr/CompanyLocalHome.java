/*
 * Generated file - Do not edit!
 */
package cmr;

import java.lang.*;
import java.util.Collection;
import javax.ejb.CreateException;
import javax.ejb.EntityBean;

/**
 * Local home interface for Company. Lookup using {1}
 * @author XDOCLET 1.1.2
 * @xdoclet-generated at Jun 5, 2002 2:49:45 PM
 */
public interface CompanyLocalHome
   extends javax.ejb.EJBLocalHome
{
   public static final String COMP_NAME="java:comp/env/ejb/CompanyLocal";
   public static final String JNDI_NAME="cmr/CompanyLocal";

   public cmr.CompanyLocal create(long id,java.lang.String name) throws javax.ejb.CreateException;

   public cmr.CompanyLocal findByPrimaryKey(cmr.CompanyKey pk) throws javax.ejb.FinderException;

}
