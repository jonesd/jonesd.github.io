/*
 * Generated file - Do not edit!
 */
package cmr;

import java.lang.*;
import java.util.Collection;
import javax.ejb.CreateException;
import javax.ejb.EntityBean;

/**
 * CMP layer for Company.
 * @author XDOCLET 1.1.2
 * @xdoclet-generated at Jun 5, 2002 2:49:46 PM
 */
public abstract class CompanyCMP
   extends cmr.CompanyBean
   implements javax.ejb.EntityBean
{

   static final long serialVersionUID = 2442840404993451638L;

   public void ejbLoad() 
   {

   }

   public void ejbStore() 
   {
   }

   public void ejbActivate() 
   {
   }

   public void ejbPassivate() 
   {

   }

   public void setEntityContext(javax.ejb.EntityContext ctx) 
   {
   }

   public void unsetEntityContext() 
   {
   }

   public void ejbRemove() 
   {
   }

   public abstract long getId() ;

   public abstract void setId( long id ) ;

   public abstract java.lang.String getName() ;

   public abstract void setName( java.lang.String name ) ;

}
