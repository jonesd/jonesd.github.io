/*
 * Generated file - Do not edit!
 */
package cmr;

import java.lang.*;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EntityBean;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import javax.rmi.PortableRemoteObject;
import javax.naming.NamingException;
import javax.naming.InitialContext;

import java.util.Hashtable;

/**
 * Utility class for Employee.
 * @author XDOCLET 1.1.2
 * @xdoclet-generated at Jun 5, 2002 2:49:46 PM
 */
public class EmployeeUtil
{
   // Home interface lookup methods

   /**
    * Obtain remote home interface from default initial context
    * @return Home interface for Employee. Lookup using JNDI_NAME
    */
   public static cmr.EmployeeHome getHome() throws NamingException
   {
      InitialContext initialContext = new InitialContext();
      try {
         java.lang.Object objRef = initialContext.lookup(cmr.EmployeeHome.JNDI_NAME);
         cmr.EmployeeHome home = (cmr.EmployeeHome)PortableRemoteObject.narrow(objRef, cmr.EmployeeHome.class);
         return home;
      } finally {
         initialContext.close();
      }
   }

   /**
    * Obtain remote home interface from parameterised initial context
    * @param environment Parameters to use for creating initial context
    * @return Home interface for Employee. Lookup using JNDI_NAME
    */
   public static cmr.EmployeeHome getHome( Hashtable environment ) throws NamingException
   {
      InitialContext initialContext = new InitialContext(environment);
      try {
         java.lang.Object objRef = initialContext.lookup(cmr.EmployeeHome.JNDI_NAME);
         cmr.EmployeeHome home = (cmr.EmployeeHome)PortableRemoteObject.narrow(objRef, cmr.EmployeeHome.class);
         return home;
      } finally {
         initialContext.close();
      }
   }

   /**
    * Obtain local home interface from default initial context
    * @return Local home interface for Employee. Lookup using JNDI_NAME
    */
   public static cmr.EmployeeLocalHome getLocalHome() throws NamingException
   {
      InitialContext initialContext = new InitialContext();
      try {
         // Local homes shouldn't be narrowed, as there is no RMI involved.
         cmr.EmployeeLocalHome localHome = (cmr.EmployeeLocalHome) initialContext.lookup(cmr.EmployeeLocalHome.JNDI_NAME);
         return localHome;
      } finally {
         initialContext.close();
      }
   }

}
