/*
 * Generated file - Do not edit!
 */
package cmr;

import java.lang.*;
import java.util.Collection;
import javax.ejb.CreateException;
import javax.ejb.EntityBean;

import javax.rmi.PortableRemoteObject;
import javax.naming.NamingException;
import javax.naming.InitialContext;

import java.util.Hashtable;

/**
 * Utility class for Company.
 * @author XDOCLET 1.1.2
 * @xdoclet-generated at Jun 5, 2002 2:49:46 PM
 */
public class CompanyUtil
{
   // Home interface lookup methods

   /**
    * Obtain remote home interface from default initial context
    * @return Home interface for Company. Lookup using JNDI_NAME
    */
   public static cmr.CompanyHome getHome() throws NamingException
   {
      InitialContext initialContext = new InitialContext();
      try {
         java.lang.Object objRef = initialContext.lookup(cmr.CompanyHome.JNDI_NAME);
         cmr.CompanyHome home = (cmr.CompanyHome)PortableRemoteObject.narrow(objRef, cmr.CompanyHome.class);
         return home;
      } finally {
         initialContext.close();
      }
   }

   /**
    * Obtain remote home interface from parameterised initial context
    * @param environment Parameters to use for creating initial context
    * @return Home interface for Company. Lookup using JNDI_NAME
    */
   public static cmr.CompanyHome getHome( Hashtable environment ) throws NamingException
   {
      InitialContext initialContext = new InitialContext(environment);
      try {
         java.lang.Object objRef = initialContext.lookup(cmr.CompanyHome.JNDI_NAME);
         cmr.CompanyHome home = (cmr.CompanyHome)PortableRemoteObject.narrow(objRef, cmr.CompanyHome.class);
         return home;
      } finally {
         initialContext.close();
      }
   }

   /**
    * Obtain local home interface from default initial context
    * @return Local home interface for Company. Lookup using JNDI_NAME
    */
   public static cmr.CompanyLocalHome getLocalHome() throws NamingException
   {
      InitialContext initialContext = new InitialContext();
      try {
         // Local homes shouldn't be narrowed, as there is no RMI involved.
         cmr.CompanyLocalHome localHome = (cmr.CompanyLocalHome) initialContext.lookup(cmr.CompanyLocalHome.JNDI_NAME);
         return localHome;
      } finally {
         initialContext.close();
      }
   }

}
