/*
 * Generated file - Do not edit!
 */
package cmr;

import java.lang.*;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EntityBean;
import javax.ejb.FinderException;
import javax.naming.NamingException;

/**
 * Home interface for Employee. Lookup using {1}
 * @author XDOCLET 1.1.2
 * @xdoclet-generated at Jun 5, 2002 2:49:45 PM
 */
public interface EmployeeHome
   extends javax.ejb.EJBHome
{
   public static final String COMP_NAME="java:comp/env/ejb/Employee";
   public static final String JNDI_NAME="cmr/Employee";

   public cmr.Employee create(long id,java.lang.String email,long companyId) throws javax.ejb.FinderException, javax.naming.NamingException, java.rmi.RemoteException,javax.ejb.CreateException;

   public cmr.Employee findByPrimaryKey(cmr.EmployeeKey pk)
      throws java.rmi.RemoteException,javax.ejb.FinderException;

}
