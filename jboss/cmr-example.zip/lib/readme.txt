To fully rebuild cmr-example, this dir will need:

ant.jar       1.4
junit.jar     3.7
log4j.jar     from jboss3.0.0
xdoclet.jar   1.1.2