package cmr;

import java.util.Collection;

import javax.ejb.CreateException;
import javax.ejb.EntityBean;

/**
 * Example Company bean
 * 
 * This is strongly based on the Version2 JBoss CMP example by Tim Chartrand
 * http://iris.cs.byu.edu/tim/462/tutorial/tutorial.html
 * 
 * @author David Jones david_jones@night.dircon.co.uk
 *
 * @ejb:bean   name="Company"
 *             type="CMP"
 *             jndi-name="cmr/Company"
 *             local-jndi-name="cmr/CompanyLocal"
 *		       cmp-version="2.x"
 *		       view-type="both"
 *		       schema="company"
 * @ejb:pk class="cmr.CompanyKey"
 * @ejb:transaction type="Required"
 * @ejb:util generate="physical"
 * 
 * @jboss:table-name table-name="COMPANY"
 * @jboss:create-table create="true"
 * @jboss:remove-table remove="true"
 */
public abstract class CompanyBean implements EntityBean {

	/////////////////////////////////////////////////////////////
	// CMP Fields ///////////////////////////////////////////////
	/////////////////////////////////////////////////////////////

	/**
	 * @ejb:pk-field
	 * @ejb:persistent-field
	 * @ejb:interface-method
	 * 
	 * @jboss:column-name name="ID"
	 * @jboss:jdbc-type type="BIGINT"
	 * @jboss:sql-type type="BIGINT"
	 */
	public abstract long getId();
	public abstract void setId(long id);

	/**
	 * @ejb:interface-method
	 * @ejb:persistent-field
	 *
	 * @jboss:column-name name="COMPANY_NAME"
	 * @jboss:jdbc-type type="VARCHAR"
	 * @jboss:sql-type type="VARCHAR(50)"
	 */
	public abstract String getName();
	public abstract void setName(String value);


	/////////////////////////////////////////////////////////////
	// CMR Fields ///////////////////////////////////////////////
	/////////////////////////////////////////////////////////////

	/**
	 * @ejb:interface-method generate="local"
	 * @ejb:relation
	 *    name="company-employee"
	 *    role-name="company-has-employees"
	 *    multiple="yes"
	 */
	public abstract Collection getEmployees();
	/**
	 * @ejb:interface-method generate="local"
	 */
	public abstract void setEmployees(Collection value);

	/////////////////////////////////////////////////////////////
	// Create Methods ///////////////////////////////////////////
	/////////////////////////////////////////////////////////////

	/**
	 * @ejb:create-method
	 */
	public CompanyKey ejbCreate(long id, String name)
			throws CreateException {

		// Set CMP fields here
		setId(id);
		setName(name);
		// Always return null from ejbCreate
		return null;
	}
	public void ejbPostCreate(long id, String name)
			throws CreateException {
				
		// Set CMR fields here
	}

}
