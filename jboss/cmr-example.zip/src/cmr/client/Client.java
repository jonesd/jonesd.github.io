package cmr.client;

import java.rmi.RemoteException;
import java.util.Properties;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import cmr.Company;
import cmr.CompanyHome;
import cmr.CompanyUtil;
import cmr.Employee;
import cmr.EmployeeHome;
import cmr.EmployeeUtil;

/**
 * Client to exercise the example EJBs
 * 
 * This is strongly based on the Version2 JBoss CMP example by Tim Chartrand
 * http://iris.cs.byu.edu/tim/462/tutorial/tutorial.html
 * 
 * @author David Jones david_jones@night.dircon.co.uk
 */
public class Client {
	/** JNDI Context Provider */
	public static String CONTEXT_PROVIDER_URL = "localhost:1099";
	/** JNDI Context class Factory Name */
	public static String CONTEXT_FACTORY_NAME = "org.jnp.interfaces.NamingContextFactory";
	public static String CONTEXT_FACTORY_PKGS = "org.jboss.naming:org.jnp.interfaces";

	private CompanyHome companyHome = null;
	private EmployeeHome employeeHome = null;

	/////////////////////////////////////////////////////////////
	// Main entry point//////////////////////////////////////////
	/////////////////////////////////////////////////////////////

	public static void main(String[] args) throws Exception {
		new Client();
	}

	/////////////////////////////////////////////////////////////
	// Constructor //////////////////////////////////////////////
	/////////////////////////////////////////////////////////////

	Client() throws Exception {
		System.out.println("--------------------------------------------------");
		System.out.println("The aim of this client is to show the CMR field that");
		System.out.println("associates the employee with its company is not being");
		System.out.println("persisted away during either create or after.");
		System.out.println("-- OR --");
		System.out.println("It shows gross-user-incompetence on my part, and I would");
		System.out.println("like to know what I'm doing wrong.");		
		System.out.println("david_jones@night.dircon.co.uk.");
		System.out.println();
		
		initializeHomes();
		
		Company company = makeCompany(99, "The BlahBlah Company");
		Employee employee = makeEmployee(2, "fred@blah.com", company);
		
		System.out.println("At this point employee's company should have been set in ejbPostCreate.");
		System.out.println("For me it hasn't, as shown above by: company=null");
		System.out.println("We will now try to explicitly associate it by setting.");
		System.out.println();

		System.out.println("--------------------------------------------------");
		System.out.println("Explicitly set company of employee:");
		employee.setCompanyById(company.getId());
		printEmployee(employee);
		
		System.out.println("On my setup the employee's comany is STILL set to null!!!!");
	}

	/////////////////////////////////////////////////////////////
	// Make Methods /////////////////////////////////////////////
	/////////////////////////////////////////////////////////////
	
	public Company makeCompany(long id, String name) throws Exception {
		System.out.println("--------------------------------------------------");
		System.out.println("Creating company with id="+id+":name=\""+name+"\"...");
		
		Company company = companyHome.create(id, name);
		System.out.println("Company created!");
		
		printCompany(company);
		
		return company;
	}

	public Employee makeEmployee(long id, String email, Company company) throws Exception {
		System.out.println("--------------------------------------------------");
		System.out.println("Creating employee with id="+id+":email=\""+email+"\":company="+company+"...");
		
		Employee employee = employeeHome.create(id, email, company.getId());
		System.out.println("Employee created!");
		
		printEmployee(employee);
		
		return employee;
	}
	
	/////////////////////////////////////////////////////////////
	// Dump EJB details methods /////////////////////////////////
	/////////////////////////////////////////////////////////////

	public void printCompany(Company company) throws RemoteException {
		System.out.println("Remote Company Details:");
		System.out.println("      id="+company.getId());
		System.out.println("    name=\""+company.getName()+"\"");
		System.out.println();
	}
	
	public void printEmployee(Employee employee) throws NamingException, FinderException, RemoteException {
		System.out.println("Remote Employee Details:");
		System.out.println("          id="+employee.getId());
		System.out.println("       email=\""+employee.getEmail()+"\"");
		System.out.println("     company="+employee.getCompanyKey());
		System.out.println();
	}

	/////////////////////////////////////////////////////////////
	// Support Methods //////////////////////////////////////////
	/////////////////////////////////////////////////////////////

	private void initializeHomes() throws Exception {
		Properties properties = new Properties();
		properties.put("Context.PROVIDER_URL", CONTEXT_PROVIDER_URL);
		properties.put("java.naming.provider.url", CONTEXT_PROVIDER_URL);
		properties.put("java.naming.factory.initial", CONTEXT_FACTORY_NAME);
		properties.put("java.naming.factory.url.pkgs", CONTEXT_FACTORY_PKGS);

		System.out.println("--------------------------------------------------");
		System.out.print("Getting Remote CompanyHome...");
		companyHome = CompanyUtil.getHome(properties);
		System.out.println(companyHome);

		System.out.print("Getting Remote EmployeeHome...");
		employeeHome = EmployeeUtil.getHome(properties);
		System.out.println(employeeHome);
		
		System.out.println();
	}
}
