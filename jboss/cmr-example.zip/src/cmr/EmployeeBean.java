package cmr;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EntityBean;
import javax.ejb.FinderException;
import javax.naming.NamingException;

/**
 * Example Employee bean
 * 
 * This is strongly based on the Version2 JBoss CMP example by Tim Chartrand
 * http://iris.cs.byu.edu/tim/462/tutorial/tutorial.html
 * 
 * @author David Jones david_jones@night.dircon.co.uk
 * 
 * @ejb:bean   name="Employee"
 *             type="CMP"
 *             jndi-name="cmr/Employee"
 *             local-jndi-name="cmr/EmployeeLocal"
 *		       cmp-version="2.x"
 *		       view-type="both"
 *		       schema="user"
 * @ejb:pk class="cmr.EmployeeKey"
 * @ejb:transaction type="Required"
 * @ejb:util generate="physical"
 * 
 * @ejb:ejb-ref ejb-name="Company"
 *              view-type="local"
 * 
 * @jboss:table-name table-name="EMPLOYEE"
 * @jboss:create-table create="true"
 * @jboss:remove-table remove="true"
 */
public abstract class EmployeeBean implements EntityBean {

	/////////////////////////////////////////////////////////////
	// CMP Fields ///////////////////////////////////////////////
	/////////////////////////////////////////////////////////////

	/**
	 * @ejb:pk-field
	 * @ejb:persistent-field
	 * @ejb:interface-method
	 *
	 * @jboss:column-name name="ID"
	 * @jboss:jdbc-type type="BIGINT"
	 * @jboss:sql-type type="BIGINT"
	 */
	public abstract long getId();
	public abstract void setId(long id);

	/**
	 * @ejb:interface-method
	 * @ejb:persistent-field
	 *
	 * @jboss:column-name name="EMAIL"
	 * @jboss:jdbc-type type="VARCHAR"
	 * @jboss:sql-type type="VARCHAR(100)"
	 */
	public abstract String getEmail();
	public abstract void setEmail(String value);

	/////////////////////////////////////////////////////////////
	// CMR Fields ///////////////////////////////////////////////
	/////////////////////////////////////////////////////////////

	/**
	 * @ejb:interface-method generate="local"
	 * @ejb:relation
	 *    name="company-employee"
	 *    role-name="user-belongsto-company"
	 * 
	 * @jboss:relation fkconstraint="true" related-pk-field="id" fk-column="COMPANY_ID"
	 */
	public abstract CompanyLocal getCompany();
	/**
	 * @ejb:interface-method generate="local"
	 */
	public abstract void setCompany(CompanyLocal value);


	/////////////////////////////////////////////////////////////
	// Create Methods ///////////////////////////////////////////
	/////////////////////////////////////////////////////////////

	/**
	 * @ejb:create-method
	 */
	public EmployeeKey ejbCreate(long id, String email, long companyId)
			throws CreateException, FinderException, NamingException {
				
		// Set CMP fields here
		setId(id);
		setEmail(email);
		// Always return null from ejbCreate
		return null;
	}
	public void ejbPostCreate(long id, String email, long companyId) throws CreateException, FinderException, NamingException {
		// Set CMR fields here
		setCompanyById(companyId);
	}

	/////////////////////////////////////////////////////////////
	// Remote Access ////////////////////////////////////////////
	/////////////////////////////////////////////////////////////

	/** 
	 * @ejb:interface-method
	 */
	public CompanyKey getCompanyKey() throws FinderException, NamingException {
		CompanyLocal companyLocal = getCompany();
		System.out.println("getCompanyKey(): companyLocal = "+companyLocal);

		if (companyLocal == null) {
			System.out.println("getCompanyKey(): Failed to find company associated with employee");
			return null;
		}
		
		CompanyKey key = (CompanyKey)companyLocal.getPrimaryKey();
		System.out.println("getCompanyKey(): key = "+key);
				
		return key;
	}
	
	/** 
	 * @ejb:interface-method
	 */
	public void setCompanyById(long companyId) throws NamingException, FinderException {
		CompanyKey key = new CompanyKey(companyId);
		System.out.println("setCompanyById(): key = "+key);
		
		CompanyLocal companyLocal = CompanyUtil.getLocalHome().findByPrimaryKey(key);
		System.out.println("setCompanyById(): companyLocal = "+companyLocal);
		
		setCompany(companyLocal);
		
		System.out.println("setCompanyById(): getCompany() = "+getCompany());
	}

}