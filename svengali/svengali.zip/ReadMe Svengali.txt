Svengali - 7 June 1998
======================

Svengali is a slowly coalescing set of tools for analysing the executing behaviour of Dolphin Smalltalk code. The tools can be applied to your own and third party code, for both time and space optimisations. It can also help with improving the structure of your application by painting a clearer picture of the interactions between the sub-components.

Svengali is supplied in a Zip file available at http://www.night.dircon.co.uk/svengali/svengali.zip. Unpack the contents of the file into your existing Dolphin installation directory, ensuring that the Use Folder Names option of your Zip tool is enabled.

Documentation is present in Packages\Svengali/Documentation/Svengali.htm.

If you have any comments, suggestions, feature requests, or bugs email them through. Inclusion of any images or sounds from abandoned industrial facilities will be greatly appreciated.

svengali@night.dircon.co.uk
http://www.night.dircon.co.uk/